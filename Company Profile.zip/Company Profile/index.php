<?php
get_header();
?>

<div class="content">
    <h2>Selamat datang di Company Profile Kami!</h2>
    <p>Deskripsi singkat perusahaan Anda.</p>
</div>

<?php
get_footer();
?>
